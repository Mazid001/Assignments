<?php include "../include/headerL.php"; ?>
<?php include "../sidebar/student_sidebar.php"; ?>
 <h1>Welcome <?php echo $_SESSION["name"]; ?></h1>