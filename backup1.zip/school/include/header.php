<head>
    <style>
    a:link {
    color: green;
    background-color: transparent;
    text-decoration: none;
   }
   </style>
</head>

<table width="80%" align="center" cellspacing="0" cellpadding="10" border="1">
    <tr>
        <td valign="middle" height="70">  
			<table width="100%">
				<tr>					
					<td>
						<a href="Dashboard.php">
							<img height="55" src="image/home.png" />
						</a>
					</td>
					<td align="right">
						<a href="Dashboard.php" >Home</a>&nbsp;|
						<a href="login.php" >Login</a></br>
						<a href="Teacher_reg.php"><img height="30" src="image/log.png">Registration As Teacher</a>&nbsp;|
						<a href="Student_reg.php"><img height="30" src="image/log.png">Registration As Student</a>
					</td>
				</tr>
			</table>
        </td>
    </tr>
    <tr>
        <td align="center">