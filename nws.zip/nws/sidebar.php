
<link rel="stylesheet" type="text/css" href="newstyle.css">

<td width="190" valign="top">
 <div class="sidebar template clear">
  <ul>
  <?php if(isset($_SESSION['un'])){
                $un= $_SESSION['un'];
  echo'
      <li><a href="home.php" >Insert Data</a></li>
      <li><a href="viewdata.php">View Data</a></li>
      <li><a href="listdata.php" >List Data</a></li>
  <li><a href="logoutm.php">Logout</a></li>';}
	 else{
		 echo'<li><a href="home.php" >Insert Data</a></li>
      <li><a href="viewdata.php">View Data</a></li>
      <li><a href="listdata.php" >List Data</a></li>
  <li><a href="loginv.html">Login</a></li>
 <li><a href="regv.html">Register</a></li>';
	 } ?>
   </ul>
   
  </div> 
 </td>
 <td valign="top">
